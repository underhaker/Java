package hw1;

public interface IFrontBookkeeper {
    String updateFront(String[] news);
    
}
